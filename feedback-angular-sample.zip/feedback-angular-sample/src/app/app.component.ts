import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  contactForm: FormGroup;
  disabledSubmitButton: boolean = true;
  rating : any;

  @HostListener('input') oninput() {
    if (this.contactForm.valid) {
      this.disabledSubmitButton = false;
    }
  }

  constructor(private fb: FormBuilder) {

    this.rating =[
      {val:1, msg:"Exceding Expectation"},
      {val:2, msg:"Meeting Expectation"},
      {val:3, msg:"Good experience"},
      {val:4, msg:"Need Improvement"},
      {val:5, msg:"Not Good"},
      {val:6, msg:"Worst"}
    ];

    this.contactForm = fb.group({
      'contactFormName': ['', Validators.required],
      'contactFormEmail': ['', Validators.compose([Validators.required, Validators.email])],
      'rating': ['', Validators.required],
      'contactFormMessage': ['']
      
    });
  }

  onSubmit() {
    
      alert('Your message has been sent.');

      console.log(this.contactForm.value);
  }
}